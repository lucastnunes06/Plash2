//
//  Projeto_FinalApp.swift
//  Projeto_Final
//
//  Created by Turma02-19 on 14/05/25.
//

import SwiftUI

@main
struct Projeto_FinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
